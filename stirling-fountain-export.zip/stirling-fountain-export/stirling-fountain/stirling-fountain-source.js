/* =============================================================================
   THE STIRLING FOUNTAIN — WEBSITE SOURCE
   Built by TouchBridge Studios · tbsites.com
   =============================================================================

   FILE MAP — this single file contains the full site source, concatenated.
   Each original file starts with a divider like:

       ===== FILE: path/to/file =====

   Files included:
     1. index.html      — the public site (references css/style.css + js/main.js)
     2. css/style.css   — full stylesheet (vintage parlor design system)
     3. js/main.js      — site interactions + LIVE flavor board loader
     4. admin.html      — password-gated Flavor Board admin panel (standalone page)

   DEPLOYMENT NOTES
   - The site is fully static — host the four files on any static host
     (Vercel, Netlify, GitHub Pages) preserving the folder layout, or use the
     bundled index.html in this zip which has CSS + JS already inlined.
   - The flavor board is loaded at runtime from the TouchBridge backend:
       GET  https://tbstudios-backend.rork.app/sf/flavors        (public)
       POST https://tbstudios-backend.rork.app/sf/flavors        (admin save)
       POST https://tbstudios-backend.rork.app/sf/flavors/reset  (admin reset)
     Saves persist in durable storage; every page load fetches fresh.
   - admin.html asks for the TouchBridge admin password on open.

============================================================================= */


/* =============================================================================
   ===== FILE: index.html =====
   ============================================================================= */

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>The Stirling Fountain — Vintage Ice Cream Parlor · Stirling, NJ</title>
  <meta name="description" content="The Stirling Fountain is a vintage-inspired ice cream parlor at 225 Main Ave, Stirling, NJ. Hard &amp; soft ice cream, milkshakes, old fashioned egg creams, banana splits and more." />
  <meta property="og:title" content="The Stirling Fountain — Vintage Ice Cream Parlor" />
  <meta property="og:description" content="Hard &amp; soft ice cream, milkshakes, egg creams and sundaes on Main Ave in Stirling, NJ. Feel like a kid again." />
  <meta property="og:type" content="website" />
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='11' r='8' fill='%23F6BFCB'/%3E%3Cpath d='M8 14 L16 30 L24 14 Z' fill='%23E8A33D'/%3E%3Ccircle cx='16' cy='6' r='2.4' fill='%23C62F3B'/%3E%3C/svg%3E" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,700;0,9..144,900;1,9..144,700&family=Karla:wght@400;600;700&family=Yellowtail&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/style.css" />
</head>
<body>

  <!-- ======================================================= header -->
  <header class="site-header" id="top">
    <div class="header-inner">
      <a class="brand" href="#top" aria-label="The Stirling Fountain — home">
        <svg class="brand-cone" viewBox="0 0 32 32" aria-hidden="true">
          <circle cx="16" cy="11" r="8" fill="#F6BFCB"/>
          <circle cx="10.5" cy="12.5" r="5.5" fill="#BFE3D4"/>
          <circle cx="21.5" cy="12.5" r="5.5" fill="#F6EBD8"/>
          <path d="M8.5 16 L16 30.5 L23.5 16 Z" fill="#E8A33D"/>
          <path d="M8.5 16 L23.5 16 L22.4 18.2 L9.6 18.2 Z" fill="#D98F2B"/>
          <circle cx="16" cy="6.4" r="2.4" fill="#C62F3B"/>
        </svg>
        <span class="brand-words">
          <span class="brand-the">The</span>
          <span class="brand-name">Stirling Fountain</span>
        </span>
      </a>
      <nav class="site-nav" id="site-nav" aria-label="Main">
        <a href="#specialties">Specialties</a>
        <a href="#flavors">Flavor Board</a>
        <a href="#story">Our Story</a>
        <a href="#visit">Visit</a>
      </nav>
      <div class="header-actions">
        <a class="btn btn-solid btn-small" href="https://www.google.com/maps/search/?api=1&amp;query=The%20Stirling%20Fountain%20225%20Main%20Ave%20Stirling%20NJ%2007980" target="_blank" rel="noopener noreferrer">Get Directions</a>
        <button class="nav-toggle" id="nav-toggle" aria-expanded="false" aria-controls="site-nav" aria-label="Menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
    <div class="awning" aria-hidden="true"></div>
  </header>

  <main>
    <!-- ===================================================== hero -->
    <section class="hero">
      <div class="sprinkles" aria-hidden="true">
        <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
      </div>
      <div class="hero-inner">
        <div class="hero-copy reveal">
          <p class="kicker">Vintage-Inspired Ice Cream Parlor · Stirling, New Jersey</p>
          <h1>
            Feel like a<br />
            <em class="script">kid again.</em>
          </h1>
          <p class="lede">
            Hard &amp; soft ice cream, hand-spun milkshakes, old fashioned egg creams and
            towering sundaes — scooped the old-school way on the corner of Main Ave.
          </p>
          <div class="hero-ctas">
            <a class="btn btn-solid" href="#flavors">See the Flavor Board</a>
            <a class="btn btn-outline" href="#visit">Find the Shop</a>
          </div>
          <div class="hero-badges">
            <span class="badge-stars" aria-label="Rated 4.6 out of 5 stars">
              <svg viewBox="0 0 110 20" class="stars" aria-hidden="true">
                <defs>
                  <linearGradient id="star-part" x1="0" x2="1" y1="0" y2="0">
                    <stop offset="60%" stop-color="#E8A33D"/><stop offset="60%" stop-color="#E3D5BE"/>
                  </linearGradient>
                </defs>
                <g fill="#E8A33D">
                  <path d="M10 1l2.7 5.6 6.1.9-4.4 4.3 1 6.1L10 15l-5.4 2.9 1-6.1L1.2 7.5l6.1-.9z"/>
                  <path d="M32 1l2.7 5.6 6.1.9-4.4 4.3 1 6.1L32 15l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>
                  <path d="M54 1l2.7 5.6 6.1.9-4.4 4.3 1 6.1L54 15l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>
                  <path d="M76 1l2.7 5.6 6.1.9-4.4 4.3 1 6.1L76 15l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>
                </g>
                <path fill="url(#star-part)" d="M98 1l2.7 5.6 6.1.9-4.4 4.3 1 6.1L98 15l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>
              </svg>
              4.6 · Loved by 80+ locals
            </span>
            <span class="badge-open" id="open-badge"><span class="dot"></span><span id="open-text">Checking hours…</span></span>
          </div>
        </div>

        <div class="hero-art reveal" aria-hidden="true">
          <div class="stamp">Est. 2023 · Main Ave</div>
          <svg class="sundae" viewBox="0 0 340 400">
            <!-- shadow -->
            <ellipse cx="170" cy="382" rx="120" ry="14" fill="#3A2419" opacity="0.12"/>
            <!-- coupe glass stem -->
            <path d="M150 320 h40 l-6 34 h-28 z" fill="#DCEAF2"/>
            <ellipse cx="170" cy="358" rx="52" ry="10" fill="#C9DEE9"/>
            <ellipse cx="170" cy="356" rx="52" ry="10" fill="#DCEAF2"/>
            <!-- coupe bowl -->
            <path d="M74 218 q6 74 96 82 q90 -8 96 -82 z" fill="#DCEAF2"/>
            <path d="M74 218 q6 74 96 82 q90 -8 96 -82 l-10 0 q-10 62 -86 70 q-76 -8 -86 -70 z" fill="#C9DEE9"/>
            <!-- scoops -->
            <circle cx="112" cy="196" r="52" fill="#BFE3D4"/>
            <circle cx="228" cy="196" r="52" fill="#F6EBD8"/>
            <circle cx="170" cy="150" r="58" fill="#F6BFCB"/>
            <!-- scoop shading -->
            <path d="M70 210 a52 52 0 0 0 60 34" fill="none" stroke="#9CCDB8" stroke-width="7" stroke-linecap="round"/>
            <path d="M186 208 a52 52 0 0 0 60 30" fill="none" stroke="#EBD9B8" stroke-width="7" stroke-linecap="round"/>
            <path d="M120 168 a58 58 0 0 0 66 34" fill="none" stroke="#EFA3B6" stroke-width="7" stroke-linecap="round"/>
            <!-- chocolate drizzle on top scoop -->
            <path d="M118 132 q10 -34 52 -38 q42 4 52 38 q-12 20 -24 6 q-8 16 -20 4 q-6 18 -16 2 q-10 16 -20 0 q-14 12 -24 -12 z" fill="#6B4226"/>
            <!-- whipped swirl -->
            <path d="M170 66 q26 4 20 26 q18 2 12 20 q-14 14 -32 8 q-18 6 -32 -8 q-6 -18 12 -20 q-6 -22 20 -26 z" fill="#FFF9F0"/>
            <!-- cherry -->
            <circle cx="170" cy="52" r="14" fill="#C62F3B"/>
            <path d="M170 40 q4 -14 16 -18" fill="none" stroke="#3E7C4F" stroke-width="4" stroke-linecap="round"/>
            <circle cx="165" cy="47" r="4" fill="#E05A64"/>
            <!-- sprinkles on scoops -->
            <g stroke-linecap="round" stroke-width="5">
              <path d="M140 118 l8 -4" stroke="#C62F3B"/>
              <path d="M196 116 l8 4" stroke="#3E7C4F"/>
              <path d="M164 100 l8 2" stroke="#E8A33D"/>
              <path d="M104 176 l8 -3" stroke="#C62F3B"/>
              <path d="M236 176 l8 3" stroke="#E8A33D"/>
              <path d="M126 214 l8 2" stroke="#6B4226"/>
              <path d="M212 218 l8 -2" stroke="#3E7C4F"/>
            </g>
            <!-- wafer -->
            <g transform="rotate(24 258 120)">
              <rect x="244" y="84" width="30" height="72" rx="6" fill="#E8A33D"/>
              <path d="M248 92 h22 M248 104 h22 M248 116 h22 M248 128 h22 M248 140 h22" stroke="#D98F2B" stroke-width="4" stroke-linecap="round"/>
            </g>
            <!-- floating cone -->
            <g class="float-cone">
              <g transform="rotate(-14 52 300)">
                <circle cx="52" cy="284" r="26" fill="#B77A46"/>
                <path d="M52 258 a26 26 0 0 1 24 16" fill="none" stroke="#9A6235" stroke-width="5" stroke-linecap="round"/>
                <path d="M30 296 L52 344 L74 296 Z" fill="#E8A33D"/>
                <path d="M34 300 l36 0 M38 310 l28 0 M43 320 l18 0" stroke="#D98F2B" stroke-width="4" stroke-linecap="round"/>
              </g>
            </g>
          </svg>
        </div>
      </div>
      <svg class="wave" viewBox="0 0 1440 70" preserveAspectRatio="none" aria-hidden="true">
        <path d="M0 40 Q60 10 120 40 T240 40 T360 40 T480 40 T600 40 T720 40 T840 40 T960 40 T1080 40 T1200 40 T1320 40 T1440 40 V70 H0 Z" fill="#C62F3B"/>
      </svg>
    </section>

    <!-- ===================================================== ticker -->
    <div class="ticker" aria-hidden="true">
      <div class="ticker-track">
        <span>Hard Scoop</span><i>●</i><span>Soft Serve</span><i>●</i><span>Milkshakes</span><i>●</i><span>Egg Creams</span><i>●</i><span>Banana Splits</span><i>●</i><span>Nasto's Italian Ice</span><i>●</i><span>Homemade Whipped Cream</span><i>●</i>
        <span>Hard Scoop</span><i>●</i><span>Soft Serve</span><i>●</i><span>Milkshakes</span><i>●</i><span>Egg Creams</span><i>●</i><span>Banana Splits</span><i>●</i><span>Nasto's Italian Ice</span><i>●</i><span>Homemade Whipped Cream</span><i>●</i>
      </div>
    </div>

    <!-- ================================================= specialties -->
    <section class="section" id="specialties">
      <div class="section-inner">
        <div class="section-head reveal">
          <p class="kicker">From the Fountain</p>
          <h2>The Specialty Board</h2>
          <p class="sub">Everything is built to order at the counter — finished with our homemade whipped cream.</p>
        </div>

        <!-- signature feature -->
        <div class="storm reveal">
          <div class="storm-swirl" aria-hidden="true">
            <svg viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="54" fill="#FFF9F0"/>
              <path d="M60 14 a46 46 0 0 1 0 92 a34 34 0 0 1 0 -68 a22 22 0 0 1 0 44 a11 11 0 0 1 0 -22" fill="none" stroke="#C62F3B" stroke-width="9" stroke-linecap="round"/>
            </svg>
          </div>
          <div class="storm-copy">
            <p class="storm-tag">House Signature</p>
            <h3>The Stirling Storm</h3>
            <p>Creamy soft serve with your favorite toppings whipped straight through it — pick your mix-ins and watch the storm roll.</p>
          </div>
          <span class="storm-arrow" aria-hidden="true">→</span>
        </div>

        <div class="cards">
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><path d="M10 22 q4 24 14 24 q10 0 14 -24 z" fill="#DCEAF2"/><circle cx="17" cy="18" r="8" fill="#F6BFCB"/><circle cx="31" cy="18" r="8" fill="#BFE3D4"/><circle cx="24" cy="12" r="8" fill="#F6EBD8"/><circle cx="24" cy="5" r="3" fill="#C62F3B"/></svg>
            </div>
            <h3>Classic Sundaes</h3>
            <p>Hot fudge, wet walnuts, rainbow sprinkles — stacked in a coupe glass like 1955.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><path d="M4 30 q20 -14 40 0 q-4 10 -20 10 q-16 0 -20 -10 z" fill="#F2D291"/><circle cx="14" cy="24" r="7" fill="#F6BFCB"/><circle cx="24" cy="22" r="7" fill="#F6EBD8"/><circle cx="34" cy="24" r="7" fill="#6B4226"/><circle cx="24" cy="15" r="2.5" fill="#C62F3B"/></svg>
            </div>
            <h3>Banana Split</h3>
            <p>Three scoops, a split banana, three toppings and a cherry on every peak.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><rect x="6" y="18" width="36" height="22" rx="5" fill="#E8A33D"/><path d="M12 24 h24 M12 30 h24 M12 36 h24 M18 20 v20 M30 20 v20" stroke="#D98F2B" stroke-width="3" stroke-linecap="round"/><circle cx="24" cy="12" r="8" fill="#F6EBD8"/><circle cx="24" cy="6" r="2.5" fill="#C62F3B"/></svg>
            </div>
            <h3>Belgian Waffle Sundae</h3>
            <p>A warm pressed waffle buried under scoops, drizzle and whipped cream.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><path d="M14 14 h20 l-3 30 h-14 z" fill="#F6BFCB"/><path d="M14 14 h20 l-1 8 h-18 z" fill="#FFF9F0"/><rect x="27" y="2" width="4" height="16" rx="2" fill="#C62F3B" transform="rotate(12 29 10)"/></svg>
            </div>
            <h3>Hand-Spun Milkshakes</h3>
            <p>Any flavor in the case, spun thick — the straw-stands-up-on-its-own kind.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><path d="M12 10 h24 l-2 34 h-20 z" fill="#DCEAF2"/><path d="M14 20 h20 l-1.5 22 h-17 z" fill="#B77A46"/><circle cx="24" cy="16" r="7" fill="#F6EBD8"/><g fill="#FFF9F0"><circle cx="18" cy="26" r="2"/><circle cx="28" cy="30" r="2"/><circle cx="22" cy="36" r="2"/></g></svg>
            </div>
            <h3>Ice Cream Floats</h3>
            <p>Root beer or cola poured slow over vanilla — fizz first, spoon second.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><path d="M15 6 h18 v6 l-3 4 v28 h-12 v-28 l-3 -4 z" fill="#DCEAF2"/><path d="M18 22 h12 v18 h-12 z" fill="#6B4226"/><path d="M18 18 h12 v6 h-12 z" fill="#FFF9F0"/></svg>
            </div>
            <h3>Old Fashioned Egg Creams</h3>
            <p>Milk, seltzer and chocolate syrup — the classic soda-fountain pour.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="13" fill="#F6EBD8"/><path d="M8 20 a18 14 0 0 1 32 0" fill="#B77A46"/><path d="M8 28 a18 14 0 0 0 32 0" fill="#B77A46"/><g fill="#6B4226"><circle cx="14" cy="18" r="1.6"/><circle cx="24" cy="16" r="1.6"/><circle cx="34" cy="18" r="1.6"/><circle cx="14" cy="31" r="1.6"/><circle cx="24" cy="33" r="1.6"/><circle cx="34" cy="31" r="1.6"/></g></svg>
            </div>
            <h3>David's Cookie Sandwich</h3>
            <p>A generous scoop pressed between two bakery-soft David's cookies.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><rect x="8" y="22" width="32" height="18" rx="4" fill="#6B4226"/><rect x="8" y="22" width="32" height="7" rx="3.5" fill="#4C2E1D"/><circle cx="24" cy="16" r="9" fill="#F6EBD8"/><path d="M18 12 a9 9 0 0 1 12 0" fill="none" stroke="#EBD9B8" stroke-width="4" stroke-linecap="round"/><circle cx="24" cy="7" r="2.5" fill="#C62F3B"/></svg>
            </div>
            <h3>Brownie à la Mode</h3>
            <p>A fudgy brownie served warm with a melting scoop of old fashioned vanilla.</p>
          </article>
          <article class="card reveal">
            <div class="card-icon" aria-hidden="true">
              <svg viewBox="0 0 48 48"><path d="M10 30 l8 -12 6 8 6 -14 8 18 z" fill="#7EC8E3"/><rect x="8" y="30" width="32" height="8" rx="4" fill="#DCEAF2"/><path d="M16 12 l2 -4 M30 8 l2 -4" stroke="#7EC8E3" stroke-width="3" stroke-linecap="round"/></svg>
            </div>
            <h3>Nasto's Italian Ice</h3>
            <p>Newark's famous ices, scooped cold and bright — the dairy-free favorite.</p>
          </article>
        </div>
      </div>
    </section>

    <!-- checkerboard divider -->
    <div class="checker" aria-hidden="true"></div>

    <!-- ================================================== flavor board -->
    <section class="section section-dark" id="flavors">
      <div class="section-inner">
        <div class="section-head reveal">
          <p class="kicker kicker-light">Twenty-eight ways to say yes</p>
          <h2>The Flavor Board</h2>
          <p class="sub">The case rotates with the seasons — these are the house favorites. Ask what's new at the window.</p>
        </div>

        <div class="tabs reveal" role="tablist" aria-label="Flavor categories">
          <button class="tab is-active" id="tab-scoop" role="tab" aria-selected="true" aria-controls="panel-scoop">Hard Scoop</button>
          <button class="tab" id="tab-soft" role="tab" aria-selected="false" aria-controls="panel-soft">Soft Serve</button>
          <button class="tab" id="tab-light" role="tab" aria-selected="false" aria-controls="panel-light">Ices &amp; Lighter</button>
        </div>

        <div class="panel is-active" id="panel-scoop" role="tabpanel" aria-labelledby="tab-scoop">
          <ul class="flavors">
            <li style="--dot:#F6EBD8">Old Fashioned Vanilla</li>
            <li style="--dot:#6B4226">Chocolate</li>
            <li style="--dot:#F49FB6">Strawberry</li>
            <li style="--dot:#D8D3CC">Cookies &amp; Cream</li>
            <li style="--dot:#F2D291">Bananas Foster</li>
            <li style="--dot:#8A5A3B">Coffee</li>
            <li style="--dot:#F3C7E0">Cake and Ice Cream</li>
            <li style="--dot:#7C4A2D">Moose Tracks</li>
            <li style="--dot:#F4EFE6">Coconut Castaway</li>
            <li style="--dot:#FBBE8E">Peachy Keen</li>
            <li style="--dot:#C64F6E">Ripe Raspberry Chocolate Chunk</li>
            <li style="--dot:#8FA6D9">Blueberry Cheesecake</li>
            <li style="--dot:#E4573D">Superman's Fruit Punch</li>
            <li style="--dot:#9ED4EC">Blue Cotton Candy</li>
            <li style="--dot:#B77A46">Campfire S'mores</li>
            <li style="--dot:#9ADBB8">Mint Chocolate Chip</li>
            <li style="--dot:#E4C48F">Cookie Dough</li>
            <li style="--dot:#F6B3BE">Strawberry Cheesecake</li>
            <li style="--dot:#4C2E1D">Chocoholic</li>
            <li style="--dot:#DDA758">Butter Pecan</li>
            <li style="--dot:#B57F4A">Salt + Caramel Cold Brew</li>
            <li style="--dot:#EFE6D2">Vanilla Chocolate Chip</li>
            <li style="--dot:#8A5A38">Brownie + Cookie Dough Delight</li>
            <li style="--dot:#7A4A26">Chocolate Peanut Butter Revel</li>
          </ul>
        </div>

        <div class="panel" id="panel-soft" role="tabpanel" aria-labelledby="tab-soft" hidden>
          <ul class="flavors flavors-big">
            <li style="--dot:#F6EBD8">Vanilla</li>
            <li style="--dot:#6B4226">Chocolate</li>
            <li style="--dot:#E4C48F">The Twist</li>
          </ul>
          <p class="panel-note">Every soft serve can become a <strong>Stirling Storm</strong> — just pick your mix-ins.</p>
        </div>

        <div class="panel" id="panel-light" role="tabpanel" aria-labelledby="tab-light" hidden>
          <ul class="flavors flavors-big">
            <li style="--dot:#7E4E8E">Vegan Black Raspberry</li>
            <li style="--dot:#F5A05A">Rainbow Sherbet</li>
            <li style="--dot:#E0788C">Cherry Vanilla <small>(No Sugar Added)</small></li>
            <li style="--dot:#7EC8E3">Nasto's Italian Ice</li>
          </ul>
          <p class="panel-note">Dairy-free, vegan and no-sugar-added picks — everyone gets a cone here.</p>
        </div>
      </div>
    </section>

    <!-- ===================================================== story -->
    <section class="section" id="story">
      <div class="section-inner story-grid">
        <div class="story-art reveal" aria-hidden="true">
          <div class="polaroid">
            <svg viewBox="0 0 260 200">
              <rect width="260" height="200" fill="#FDEFDC"/>
              <rect x="0" y="150" width="260" height="50" fill="#C62F3B"/>
              <rect x="0" y="150" width="260" height="8" fill="#A32531"/>
              <!-- storefront -->
              <rect x="30" y="60" width="200" height="90" fill="#FFF7EA" stroke="#3A2419" stroke-width="3"/>
              <!-- awning -->
              <g>
                <path d="M22 60 h216 v14 h-216 z" fill="#C62F3B"/>
                <path d="M22 74 a9 7 0 0 0 18 0 z M40 74 a9 7 0 0 0 18 0 z M58 74 a9 7 0 0 0 18 0 z M76 74 a9 7 0 0 0 18 0 z M94 74 a9 7 0 0 0 18 0 z M112 74 a9 7 0 0 0 18 0 z M130 74 a9 7 0 0 0 18 0 z M148 74 a9 7 0 0 0 18 0 z M166 74 a9 7 0 0 0 18 0 z M184 74 a9 7 0 0 0 18 0 z M202 74 a9 7 0 0 0 18 0 z M220 74 a9 7 0 0 0 18 0 z" fill="#C62F3B"/>
                <path d="M40 60 v14 M76 60 v14 M112 60 v14 M148 60 v14 M184 60 v14 M220 60 v14" stroke="#FFF7EA" stroke-width="7"/>
              </g>
              <!-- door + windows -->
              <rect x="112" y="96" width="36" height="54" fill="#3A2419"/>
              <circle cx="142" cy="124" r="2.5" fill="#E8A33D"/>
              <rect x="44" y="96" width="52" height="34" fill="#BFE3D4" stroke="#3A2419" stroke-width="2.5"/>
              <rect x="164" y="96" width="52" height="34" fill="#BFE3D4" stroke="#3A2419" stroke-width="2.5"/>
              <!-- sign -->
              <rect x="76" y="38" width="108" height="18" rx="9" fill="#3A2419"/>
              <circle cx="86" cy="47" r="3" fill="#E8A33D"/><circle cx="174" cy="47" r="3" fill="#E8A33D"/>
              <!-- cone on roof -->
              <g transform="rotate(-8 60 30)">
                <circle cx="60" cy="26" r="10" fill="#F6BFCB"/>
                <path d="M52 32 L60 50 L68 32 Z" fill="#E8A33D"/>
              </g>
            </svg>
            <p class="polaroid-caption script">the corner of Main Ave</p>
          </div>
          <div class="sticker">Homemade<br/>Whipped Cream</div>
        </div>
        <div class="story-copy reveal">
          <p class="kicker">Our Story</p>
          <h2>A soda fountain for<br/>Long Hill's main street</h2>
          <p>
            The Stirling Fountain opened its window in the summer of 2023 and became the town's
            gathering spot almost overnight — the line of kids on bikes gave it away.
          </p>
          <p>
            Everything about the place is a little bit yesterday: coupe glasses, egg creams, wafer
            cookies in every sundae and whipped cream made in-house each morning. Grab a seat in the
            sunny outdoor spot and stay a while.
          </p>
          <ul class="story-points">
            <li><span aria-hidden="true">✓</span> Gluten-free friendly, with clearly marked picks</li>
            <li><span aria-hidden="true">✓</span> Vegan &amp; no-sugar-added flavors always in the case</li>
            <li><span aria-hidden="true">✓</span> Sunny outdoor seating steps from the Passaic trail</li>
          </ul>
        </div>
      </div>
    </section>

    <!-- ==================================================== reviews -->
    <section class="section section-red" id="reviews">
      <div class="section-inner">
        <div class="section-head reveal">
          <p class="kicker kicker-cream">Word on Main Ave</p>
          <h2>The town approves</h2>
        </div>
        <div class="review-grid">
          <figure class="review reveal">
            <blockquote>“Hands down one of the best ice cream spots I've ever been to. That classic, old-school vibe makes you feel like a kid again the second you walk up.”</blockquote>
            <figcaption>Google review</figcaption>
          </figure>
          <figure class="review reveal">
            <blockquote>“Super creamy, great flavor options, and they give you big scoops. Everything just tastes fresh and homemade.”</blockquote>
            <figcaption>Google review</figcaption>
          </figure>
          <figure class="review reveal">
            <blockquote>“The service, the flavors, the clear gluten-free of it all. It feels like a classic ice cream shop.”</blockquote>
            <figcaption>Yelp review</figcaption>
          </figure>
        </div>
        <div class="scorebars reveal">
          <div class="scorebar"><span class="scorebar-label">Food</span><span class="scorebar-track"><span class="scorebar-fill" style="--w:98%"></span></span><span class="scorebar-num">4.9</span></div>
          <div class="scorebar"><span class="scorebar-label">Atmosphere</span><span class="scorebar-track"><span class="scorebar-fill" style="--w:92%"></span></span><span class="scorebar-num">4.6</span></div>
          <div class="scorebar"><span class="scorebar-label">Service</span><span class="scorebar-track"><span class="scorebar-fill" style="--w:90%"></span></span><span class="scorebar-num">4.5</span></div>
          <p class="scorebar-note">Compiled from 80+ public ratings</p>
        </div>
      </div>
    </section>

    <!-- ====================================================== visit -->
    <section class="section" id="visit">
      <div class="section-inner">
        <div class="section-head reveal">
          <p class="kicker">Come say hi</p>
          <h2>Visit the Fountain</h2>
        </div>
        <div class="visit-grid">
          <div class="visit-card reveal">
            <h3>Summer Hours</h3>
            <table class="hours" id="hours-table">
              <tbody>
                <tr data-day="1"><th scope="row">Monday</th><td>1 PM – 9 PM</td></tr>
                <tr data-day="2"><th scope="row">Tuesday</th><td>1 PM – 9 PM</td></tr>
                <tr data-day="3"><th scope="row">Wednesday</th><td>1 PM – 9 PM</td></tr>
                <tr data-day="4"><th scope="row">Thursday</th><td>1 PM – 10 PM</td></tr>
                <tr data-day="5"><th scope="row">Friday</th><td>1 PM – 10 PM</td></tr>
                <tr data-day="6"><th scope="row">Saturday</th><td>1 PM – 10 PM</td></tr>
                <tr data-day="0"><th scope="row">Sunday</th><td>1 PM – 9 PM</td></tr>
              </tbody>
            </table>
            <p class="visit-note" id="visit-open-note"></p>
          </div>
          <div class="visit-card reveal">
            <h3>Find Us</h3>
            <p class="address">
              225 Main Ave<br />
              Stirling, NJ 07980
            </p>
            <p class="address-note">On the corner of Main Ave — look for the line of bikes out front.</p>
            <div class="visit-ctas">
              <a class="btn btn-solid" href="https://www.google.com/maps/search/?api=1&amp;query=The%20Stirling%20Fountain%20225%20Main%20Ave%20Stirling%20NJ%2007980" target="_blank" rel="noopener noreferrer">Open in Maps</a>
              <a class="btn btn-outline" href="#flavors">Plan Your Order</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <!-- ====================================================== footer -->
  <footer class="site-footer">
    <div class="awning awning-flip" aria-hidden="true"></div>
    <div class="footer-inner">
      <p class="footer-brand script">The Stirling Fountain</p>
      <p class="footer-line">225 Main Ave · Stirling, NJ 07980</p>
      <p class="footer-line footer-small">Vintage-inspired ice cream parlor — hard &amp; soft ice cream, milkshakes, specialty dishes and more.</p>
      <p class="footer-credit">© <span id="year"></span> The Stirling Fountain · Site crafted by <strong>TouchBridge Studios</strong></p>
    </div>
  </footer>

  <a class="to-top" href="#top" aria-label="Back to top">
    <svg viewBox="0 0 32 32" aria-hidden="true">
      <circle cx="16" cy="11" r="8" fill="#F6BFCB"/>
      <path d="M8 14 L16 30 L24 14 Z" fill="#E8A33D"/>
      <circle cx="16" cy="6" r="2.4" fill="#C62F3B"/>
    </svg>
  </a>

  <script src="js/main.js"></script>
</body>
</html>


/* =============================================================================
   ===== FILE: css/style.css =====
   ============================================================================= */

/* ==========================================================================
   The Stirling Fountain — vintage ice cream parlor
   cream & cherry palette · Fraunces / Karla / Yellowtail
   ========================================================================== */

:root {
  --cream: #FFF7EA;
  --paper: #FDEFDC;
  --ink: #3A2419;
  --red: #C62F3B;
  --red-dark: #A32531;
  --gold: #E8A33D;
  --gold-dark: #D98F2B;
  --mint: #BFE3D4;
  --pink: #F6BFCB;
  --blue: #DCEAF2;
  --line: #EAD9BE;
  --shadow: 0 10px 30px rgba(58, 36, 25, 0.12);
}

* { box-sizing: border-box; margin: 0; padding: 0; }

html { scroll-behavior: smooth; }

body {
  font-family: "Karla", system-ui, sans-serif;
  background: var(--cream);
  color: var(--ink);
  line-height: 1.6;
  -webkit-font-smoothing: antialiased;
}

img, svg { display: block; max-width: 100%; }

h1, h2, h3 {
  font-family: "Fraunces", Georgia, serif;
  font-weight: 900;
  line-height: 1.08;
  letter-spacing: -0.01em;
}

.script {
  font-family: "Yellowtail", cursive;
  font-weight: 400;
  letter-spacing: 0;
}

a { color: inherit; }

/* ---------------------------------------------------------------- buttons */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 13px 26px;
  border-radius: 999px;
  border: 2.5px solid var(--ink);
  font-family: "Karla", sans-serif;
  font-weight: 700;
  font-size: 15px;
  text-decoration: none;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease, background 0.2s ease;
}
.btn:hover { transform: translateY(-2px); box-shadow: 0 6px 0 rgba(58, 36, 25, 0.18); }
.btn:active { transform: translateY(0); box-shadow: none; }
.btn-solid { background: var(--red); border-color: var(--red-dark); color: #fff; }
.btn-solid:hover { background: var(--red-dark); }
.btn-outline { background: transparent; color: var(--ink); }
.btn-outline:hover { background: rgba(58, 36, 25, 0.06); }
.btn-small { padding: 9px 18px; font-size: 13px; }

/* ----------------------------------------------------------------- header */
.site-header {
  position: sticky;
  top: 0;
  z-index: 50;
  background: var(--cream);
}

.header-inner {
  max-width: 1120px;
  margin: 0 auto;
  padding: 14px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.brand { display: flex; align-items: center; gap: 10px; text-decoration: none; }
.brand-cone { width: 40px; height: 40px; transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); }
.brand:hover .brand-cone { transform: rotate(-10deg) scale(1.08); }
.brand-words { display: flex; flex-direction: column; line-height: 1; }
.brand-the { font-family: "Yellowtail", cursive; font-size: 15px; color: var(--red); }
.brand-name {
  font-family: "Fraunces", serif;
  font-weight: 900;
  font-size: 19px;
  letter-spacing: 0.01em;
}

.site-nav { display: flex; gap: 4px; }
.site-nav a {
  padding: 8px 14px;
  border-radius: 999px;
  text-decoration: none;
  font-weight: 700;
  font-size: 14.5px;
  transition: background 0.2s ease, color 0.2s ease;
}
.site-nav a:hover { background: var(--red); color: #fff; }

.header-actions { display: flex; align-items: center; gap: 10px; }

.nav-toggle {
  display: none;
  flex-direction: column;
  gap: 5px;
  padding: 10px;
  background: none;
  border: none;
  cursor: pointer;
}
.nav-toggle span {
  width: 24px;
  height: 3px;
  border-radius: 2px;
  background: var(--ink);
  transition: transform 0.25s ease, opacity 0.2s ease;
}
.nav-toggle[aria-expanded="true"] span:nth-child(1) { transform: translateY(8px) rotate(45deg); }
.nav-toggle[aria-expanded="true"] span:nth-child(2) { opacity: 0; }
.nav-toggle[aria-expanded="true"] span:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }

/* red & white scalloped awning */
.awning {
  height: 22px;
  background:
    radial-gradient(circle at 12px 0, transparent 11px, transparent 12px) 0 12px / 48px 12px repeat-x,
    repeating-linear-gradient(90deg, var(--red) 0 24px, #fff 24px 48px);
  position: relative;
}
.awning::after {
  content: "";
  position: absolute;
  left: 0; right: 0; bottom: -12px;
  height: 12px;
  background:
    radial-gradient(circle at 12px 0px, var(--red) 11px, transparent 12px) 0 0 / 48px 12px repeat-x,
    radial-gradient(circle at 36px 0px, #fff 11px, transparent 12px) 0 0 / 48px 12px repeat-x;
}
.awning-flip { transform: scaleY(-1); }
.awning-flip::after { display: none; }

/* ------------------------------------------------------------------- hero */
.hero {
  position: relative;
  overflow: hidden;
  padding: 76px 20px 0;
  background:
    radial-gradient(700px 340px at 85% 10%, rgba(246, 191, 203, 0.35), transparent 65%),
    radial-gradient(600px 300px at 8% 85%, rgba(191, 227, 212, 0.4), transparent 60%),
    var(--cream);
}

.hero-inner {
  max-width: 1120px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1.1fr 0.9fr;
  gap: 40px;
  align-items: center;
  padding-bottom: 90px;
}

.kicker {
  font-size: 12.5px;
  font-weight: 700;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--red);
  margin-bottom: 14px;
}
.kicker-light { color: var(--gold); }
.kicker-cream { color: var(--pink); }

.hero h1 {
  font-size: clamp(3rem, 7vw, 5.2rem);
  margin-bottom: 20px;
}
.hero h1 .script {
  color: var(--red);
  font-size: 1.12em;
  display: inline-block;
  transform: rotate(-2deg);
}

.lede {
  font-size: 17.5px;
  max-width: 480px;
  color: rgba(58, 36, 25, 0.78);
  margin-bottom: 28px;
}

.hero-ctas { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 28px; }

.hero-badges { display: flex; flex-wrap: wrap; align-items: center; gap: 14px; }
.badge-stars {
  display: inline-flex;
  align-items: center;
  gap: 9px;
  font-weight: 700;
  font-size: 14px;
  background: #fff;
  border: 2px solid var(--line);
  border-radius: 999px;
  padding: 8px 16px;
}
.stars { width: 96px; height: 18px; }
.badge-open {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-weight: 700;
  font-size: 14px;
  color: var(--ink);
  background: var(--mint);
  border-radius: 999px;
  padding: 8px 16px;
}
.badge-open .dot {
  width: 9px; height: 9px;
  border-radius: 50%;
  background: #3E7C4F;
  animation: pulse 2s ease-in-out infinite;
}
.badge-open.is-closed { background: var(--paper); }
.badge-open.is-closed .dot { background: var(--gold-dark); animation: none; }

@keyframes pulse { 0%, 100% { opacity: 0.5; } 50% { opacity: 1; } }

/* hero art */
.hero-art { position: relative; }
.hero-art .sundae { width: min(400px, 90%); margin: 0 auto; animation: bob 5s ease-in-out infinite; }
@keyframes bob { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-12px); } }
.float-cone { animation: drift 6s ease-in-out infinite; transform-origin: 52px 300px; }
@keyframes drift { 0%, 100% { transform: translateY(0) rotate(0deg); } 50% { transform: translateY(-14px) rotate(4deg); } }

.stamp {
  position: absolute;
  top: 0;
  right: 6%;
  z-index: 2;
  background: var(--gold);
  color: var(--ink);
  font-weight: 700;
  font-size: 12.5px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  padding: 10px 16px;
  border-radius: 999px;
  transform: rotate(6deg);
  box-shadow: var(--shadow);
}

/* falling sprinkles */
.sprinkles { position: absolute; inset: 0; pointer-events: none; }
.sprinkles i {
  position: absolute;
  top: -20px;
  width: 5px;
  height: 14px;
  border-radius: 3px;
  opacity: 0.7;
  animation: fall linear infinite;
}
@keyframes fall {
  from { transform: translateY(-5vh) rotate(0deg); }
  to { transform: translateY(110vh) rotate(340deg); }
}
.sprinkles i:nth-child(1)  { left: 4%;  background: var(--red);  animation-duration: 9s;  animation-delay: 0s; }
.sprinkles i:nth-child(2)  { left: 12%; background: var(--gold); animation-duration: 12s; animation-delay: 2s; }
.sprinkles i:nth-child(3)  { left: 19%; background: var(--mint); animation-duration: 10s; animation-delay: 5s; }
.sprinkles i:nth-child(4)  { left: 27%; background: var(--pink); animation-duration: 13s; animation-delay: 1s; }
.sprinkles i:nth-child(5)  { left: 34%; background: #6B4226;     animation-duration: 9s;  animation-delay: 6s; }
.sprinkles i:nth-child(6)  { left: 42%; background: var(--gold); animation-duration: 11s; animation-delay: 3s; }
.sprinkles i:nth-child(7)  { left: 49%; background: var(--red);  animation-duration: 14s; animation-delay: 7s; }
.sprinkles i:nth-child(8)  { left: 57%; background: var(--mint); animation-duration: 10s; animation-delay: 0.5s; }
.sprinkles i:nth-child(9)  { left: 64%; background: var(--pink); animation-duration: 12s; animation-delay: 4s; }
.sprinkles i:nth-child(10) { left: 72%; background: var(--gold); animation-duration: 9s;  animation-delay: 8s; }
.sprinkles i:nth-child(11) { left: 79%; background: var(--red);  animation-duration: 13s; animation-delay: 2.5s; }
.sprinkles i:nth-child(12) { left: 86%; background: #6B4226;     animation-duration: 11s; animation-delay: 5.5s; }
.sprinkles i:nth-child(13) { left: 92%; background: var(--mint); animation-duration: 10s; animation-delay: 1.5s; }
.sprinkles i:nth-child(14) { left: 97%; background: var(--pink); animation-duration: 12s; animation-delay: 6.5s; }

.wave { position: absolute; left: 0; right: 0; bottom: -1px; width: 100%; height: 70px; }

/* ------------------------------------------------------------------ ticker */
.ticker { background: var(--red); color: #FFF7EA; overflow: hidden; padding: 12px 0; }
.ticker-track {
  display: flex;
  align-items: center;
  gap: 26px;
  width: max-content;
  white-space: nowrap;
  animation: ticker 28s linear infinite;
  font-family: "Fraunces", serif;
  font-weight: 700;
  font-size: 15.5px;
  letter-spacing: 0.04em;
}
.ticker-track i { font-style: normal; font-size: 9px; color: var(--gold); }
@keyframes ticker { from { transform: translateX(0); } to { transform: translateX(-50%); } }

/* ---------------------------------------------------------------- sections */
.section { padding: 88px 20px; }
.section-inner { max-width: 1120px; margin: 0 auto; }

.section-head { text-align: center; max-width: 620px; margin: 0 auto 48px; }
.section-head h2 { font-size: clamp(2.1rem, 4.5vw, 3.1rem); margin-bottom: 12px; }
.section-head .sub { color: rgba(58, 36, 25, 0.7); font-size: 16.5px; }

/* ------------------------------------------------------------------- storm */
.storm {
  display: flex;
  align-items: center;
  gap: 24px;
  background: var(--paper);
  border: 2.5px solid var(--gold);
  border-radius: 24px;
  padding: 22px 30px;
  margin-bottom: 36px;
  box-shadow: var(--shadow);
  position: relative;
  overflow: hidden;
}
.storm::before {
  content: "";
  position: absolute;
  inset: 0;
  background: radial-gradient(500px 130px at 100% 0%, rgba(232, 163, 61, 0.14), transparent 70%);
}
.storm-swirl { width: 84px; flex-shrink: 0; animation: spin 14s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.storm-tag {
  font-size: 11.5px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  color: var(--gold-dark);
  margin-bottom: 4px;
}
.storm-copy h3 { font-size: 26px; margin-bottom: 6px; }
.storm-copy p { color: rgba(58, 36, 25, 0.75); max-width: 560px; }
.storm-arrow { margin-left: auto; font-size: 30px; color: var(--red); flex-shrink: 0; }

/* ------------------------------------------------------------------- cards */
.cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 18px;
}
.card {
  background: #fff;
  border: 2px solid var(--line);
  border-radius: 20px;
  padding: 26px 22px;
  text-align: center;
  transition: transform 0.25s cubic-bezier(0.22, 1, 0.36, 1), box-shadow 0.25s ease, border-color 0.25s ease;
}
.card:hover {
  transform: translateY(-6px) rotate(-0.5deg);
  border-color: var(--red);
  box-shadow: var(--shadow);
}
.card-icon {
  width: 64px;
  height: 64px;
  margin: 0 auto 16px;
  background: var(--paper);
  border-radius: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10px;
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.card:hover .card-icon { transform: scale(1.12) rotate(6deg); }
.card h3 { font-size: 19px; margin-bottom: 8px; }
.card p { font-size: 14px; color: rgba(58, 36, 25, 0.72); }

/* --------------------------------------------------------------- checker */
.checker {
  height: 36px;
  background:
    repeating-conic-gradient(var(--ink) 0% 25%, var(--cream) 0% 50%) 0 0 / 36px 36px;
  opacity: 0.9;
}

/* ------------------------------------------------------------ flavor board */
.section-dark { background: var(--ink); color: var(--cream); }
.section-dark .section-head h2 { color: #fff; }
.section-dark .section-head .sub { color: rgba(255, 247, 234, 0.65); }

.tabs {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 36px;
}
.tab {
  font-family: "Karla", sans-serif;
  font-weight: 700;
  font-size: 15px;
  padding: 11px 26px;
  border-radius: 999px;
  border: 2px solid rgba(255, 247, 234, 0.3);
  background: transparent;
  color: rgba(255, 247, 234, 0.75);
  cursor: pointer;
  transition: all 0.2s ease;
}
.tab:hover { border-color: var(--gold); color: #fff; }
.tab.is-active {
  background: var(--red);
  border-color: var(--red);
  color: #fff;
  box-shadow: 0 6px 18px rgba(198, 47, 59, 0.4);
}

.panel { display: none; }
.panel.is-active { display: block; animation: panelIn 0.4s ease; }
@keyframes panelIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }

.flavors {
  list-style: none;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px 22px;
  max-width: 900px;
  margin: 0 auto;
}
.flavors li {
  display: flex;
  align-items: center;
  gap: 12px;
  font-family: "Fraunces", serif;
  font-weight: 500;
  font-size: 17px;
  padding: 9px 14px;
  border-radius: 12px;
  background: rgba(255, 247, 234, 0.05);
  border: 1px solid rgba(255, 247, 234, 0.09);
  transition: background 0.2s ease, transform 0.2s ease;
}
.flavors li:hover { background: rgba(255, 247, 234, 0.12); transform: translateX(4px); }
.flavors li::before {
  content: "";
  width: 16px;
  height: 16px;
  border-radius: 50%;
  flex-shrink: 0;
  background: var(--dot, var(--pink));
  box-shadow: inset 0 -3px 0 rgba(0, 0, 0, 0.14);
}
.flavors li small {
  font-family: "Karla", sans-serif;
  font-size: 12px;
  color: rgba(255, 247, 234, 0.6);
}

.flavors-big { grid-template-columns: repeat(3, 1fr); max-width: 760px; }
.flavors-big li { font-size: 21px; padding: 16px 18px; justify-content: center; }

.panel-note {
  text-align: center;
  margin-top: 26px;
  color: rgba(255, 247, 234, 0.7);
  font-size: 15px;
}
.panel-note strong { color: var(--gold); }

/* ------------------------------------------------------------------- story */
.story-grid {
  display: grid;
  grid-template-columns: 0.9fr 1.1fr;
  gap: 56px;
  align-items: center;
}

.story-art { position: relative; }
.polaroid {
  background: #fff;
  padding: 14px 14px 10px;
  border-radius: 6px;
  box-shadow: var(--shadow);
  transform: rotate(-3deg);
  transition: transform 0.3s ease;
}
.polaroid:hover { transform: rotate(-1deg) scale(1.02); }
.polaroid svg { border-radius: 3px; }
.polaroid-caption { text-align: center; font-size: 22px; color: var(--ink); padding: 10px 0 4px; }

.sticker {
  position: absolute;
  right: -14px;
  bottom: -18px;
  width: 118px;
  height: 118px;
  border-radius: 50%;
  background: var(--red);
  color: #fff;
  font-family: "Fraunces", serif;
  font-weight: 700;
  font-size: 14.5px;
  line-height: 1.25;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  transform: rotate(8deg);
  box-shadow: var(--shadow);
  border: 3px dashed rgba(255, 255, 255, 0.5);
  animation: wobble 5s ease-in-out infinite;
}
@keyframes wobble { 0%, 100% { transform: rotate(8deg); } 50% { transform: rotate(2deg); } }

.story-copy h2 { font-size: clamp(2rem, 4vw, 2.8rem); margin-bottom: 18px; }
.story-copy p { color: rgba(58, 36, 25, 0.78); margin-bottom: 14px; font-size: 16.5px; }

.story-points { list-style: none; margin-top: 22px; }
.story-points li {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  font-weight: 700;
  font-size: 15.5px;
  padding: 7px 0;
}
.story-points span {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: var(--mint);
  color: var(--ink);
  font-size: 13px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin-top: 1px;
}

/* ----------------------------------------------------------------- reviews */
.section-red { background: var(--red); color: #FFF7EA; }
.section-red .section-head h2 { color: #fff; }

.review-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 18px;
  margin-bottom: 48px;
}
.review {
  background: #FFF7EA;
  color: var(--ink);
  border-radius: 20px;
  padding: 28px 26px;
  position: relative;
  transition: transform 0.25s ease;
}
.review:hover { transform: translateY(-5px) rotate(0.5deg); }
.review::before {
  content: "“";
  font-family: "Fraunces", serif;
  font-size: 64px;
  line-height: 1;
  color: var(--red);
  position: absolute;
  top: 10px;
  left: 20px;
  opacity: 0.35;
}
.review blockquote { font-family: "Fraunces", serif; font-size: 16.5px; font-weight: 500; margin-bottom: 14px; padding-top: 14px; }
.review figcaption { font-size: 13px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.12em; color: rgba(58, 36, 25, 0.55); }

.scorebars { max-width: 560px; margin: 0 auto; }
.scorebar { display: flex; align-items: center; gap: 14px; margin-bottom: 12px; }
.scorebar-label { width: 110px; font-weight: 700; font-size: 14.5px; text-align: right; }
.scorebar-track {
  flex: 1;
  height: 12px;
  border-radius: 999px;
  background: rgba(255, 247, 234, 0.25);
  overflow: hidden;
}
.scorebar-fill {
  display: block;
  height: 100%;
  width: 0;
  border-radius: 999px;
  background: var(--gold);
  transition: width 1.1s cubic-bezier(0.22, 1, 0.36, 1);
}
.is-visible .scorebar-fill, .scorebar.is-visible .scorebar-fill { width: var(--w, 0%); }
.scorebars.is-visible .scorebar-fill { width: var(--w, 0%); }
.scorebar-num { width: 36px; font-family: "Fraunces", serif; font-weight: 700; font-size: 16px; }
.scorebar-note { text-align: center; margin-top: 16px; font-size: 13px; color: rgba(255, 247, 234, 0.7); }

/* ------------------------------------------------------------------- visit */
.visit-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 18px;
  max-width: 860px;
  margin: 0 auto;
}
.visit-card {
  background: #fff;
  border: 2px solid var(--line);
  border-radius: 22px;
  padding: 32px 30px;
  box-shadow: var(--shadow);
}
.visit-card h3 { font-size: 22px; margin-bottom: 16px; color: var(--red); }

.hours { width: 100%; border-collapse: collapse; }
.hours th, .hours td { padding: 8px 4px; font-size: 15px; text-align: left; border-bottom: 1px dashed var(--line); }
.hours th { font-weight: 700; }
.hours td { text-align: right; color: rgba(58, 36, 25, 0.75); }
.hours tr.is-today th, .hours tr.is-today td {
  color: var(--red);
  font-weight: 800;
}
.visit-note { margin-top: 14px; font-size: 13.5px; font-weight: 700; color: #3E7C4F; }

.address { font-family: "Fraunces", serif; font-weight: 700; font-size: 22px; margin-bottom: 8px; }
.address-note { font-size: 14.5px; color: rgba(58, 36, 25, 0.7); margin-bottom: 22px; }
.visit-ctas { display: flex; flex-wrap: wrap; gap: 10px; }

/* ------------------------------------------------------------------ footer */
.site-footer { background: var(--ink); color: var(--cream); position: relative; }
.footer-inner { max-width: 1120px; margin: 0 auto; padding: 60px 20px 40px; text-align: center; }
.footer-brand { font-size: 38px; color: var(--pink); margin-bottom: 8px; }
.footer-line { font-size: 15px; color: rgba(255, 247, 234, 0.8); }
.footer-small { font-size: 13.5px; color: rgba(255, 247, 234, 0.55); margin-top: 4px; }
.footer-credit { margin-top: 26px; font-size: 12.5px; color: rgba(255, 247, 234, 0.45); }
.footer-credit strong { color: rgba(255, 247, 234, 0.75); }

/* ------------------------------------------------------------------ to-top */
.to-top {
  position: fixed;
  right: 18px;
  bottom: 18px;
  z-index: 40;
  width: 52px;
  height: 52px;
  border-radius: 50%;
  background: #fff;
  border: 2px solid var(--line);
  box-shadow: var(--shadow);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 9px;
  opacity: 0;
  pointer-events: none;
  transform: translateY(10px);
  transition: opacity 0.3s ease, transform 0.3s ease;
}
.to-top.is-shown { opacity: 1; pointer-events: auto; transform: translateY(0); }
.to-top:hover { transform: translateY(-3px); }

/* ------------------------------------------------------------------ reveal */
.reveal { opacity: 0; transform: translateY(26px); transition: opacity 0.7s ease, transform 0.7s cubic-bezier(0.22, 1, 0.36, 1); }
.reveal.is-visible { opacity: 1; transform: translateY(0); }

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
  .reveal { opacity: 1; transform: none; }
}

/* -------------------------------------------------------------- responsive */
@media (max-width: 900px) {
  .hero-inner { grid-template-columns: 1fr; padding-bottom: 70px; }
  .hero-art { order: -1; }
  .hero-art .sundae { width: min(300px, 70%); }
  .cards { grid-template-columns: repeat(2, 1fr); }
  .flavors { grid-template-columns: repeat(2, 1fr); }
  .story-grid { grid-template-columns: 1fr; gap: 60px; }
  .review-grid { grid-template-columns: 1fr; }
  .visit-grid { grid-template-columns: 1fr; }
}

@media (max-width: 720px) {
  .site-nav {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    flex-direction: column;
    background: var(--cream);
    border-bottom: 3px solid var(--red);
    padding: 12px 20px 18px;
    box-shadow: var(--shadow);
  }
  .site-nav.is-open { display: flex; }
  .site-nav a { padding: 12px 14px; font-size: 16px; }
  .nav-toggle { display: flex; }
  .header-actions .btn { display: none; }
  .section { padding: 64px 16px; }
  .cards { grid-template-columns: 1fr; }
  .flavors, .flavors-big { grid-template-columns: 1fr; }
  .storm { flex-direction: column; text-align: center; }
  .storm-arrow { display: none; }
  .sticker { right: 4px; }
}


/* =============================================================================
   ===== FILE: js/main.js =====
   ============================================================================= */

/* The Stirling Fountain — site interactions + live flavor board.
   The flavor board is fetched fresh from the TouchBridge backend on every
   page load, so whatever is saved in the admin panel is what visitors see.
   The HTML's built-in lists are only a fallback if the network fails. */

(function () {
  "use strict";

  var API = "https://tbstudios-backend.rork.app";

  /* ------------------------------------------------------------ year */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  /* ------------------------------------------------------ nav toggle */
  var navToggle = document.getElementById("nav-toggle");
  var siteNav = document.getElementById("site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      var open = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    siteNav.addEventListener("click", function (e) {
      if (e.target && e.target.tagName === "A") {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* -------------------------------------------------- reveal on scroll */
  var revealEls = document.querySelectorAll(".reveal, .scorebars");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.16 }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("is-visible"); });
  }

  /* --------------------------------------------------------- to-top */
  var toTop = document.querySelector(".to-top");
  if (toTop) {
    var onScroll = function () {
      toTop.classList.toggle("is-shown", window.scrollY > 600);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* ----------------------------------------------------------- tabs */
  var tabs = Array.prototype.slice.call(document.querySelectorAll(".tab"));
  function activateTab(tab) {
    tabs.forEach(function (t) {
      var active = t === tab;
      t.classList.toggle("is-active", active);
      t.setAttribute("aria-selected", active ? "true" : "false");
      var panel = document.getElementById(t.getAttribute("aria-controls"));
      if (panel) {
        panel.classList.toggle("is-active", active);
        if (active) panel.removeAttribute("hidden");
        else panel.setAttribute("hidden", "");
      }
    });
  }
  tabs.forEach(function (tab) {
    tab.addEventListener("click", function () { activateTab(tab); });
  });

  /* --------------------------------------------- hours + open badge */
  // Hours as [openMinutes, closeMinutes] per JS day (0 = Sunday).
  var HOURS = {
    0: [13 * 60, 21 * 60],
    1: [13 * 60, 21 * 60],
    2: [13 * 60, 21 * 60],
    3: [13 * 60, 21 * 60],
    4: [13 * 60, 22 * 60],
    5: [13 * 60, 22 * 60],
    6: [13 * 60, 22 * 60],
  };

  var now = new Date();
  var today = now.getDay();
  var minutes = now.getHours() * 60 + now.getMinutes();
  var span = HOURS[today];
  var isOpen = span ? minutes >= span[0] && minutes < span[1] : false;

  var row = document.querySelector('#hours-table tr[data-day="' + today + '"]');
  if (row) row.classList.add("is-today");

  function fmt(mins) {
    var h = Math.floor(mins / 60);
    var suffix = h >= 12 ? "PM" : "AM";
    var display = h % 12 === 0 ? 12 : h % 12;
    return display + " " + suffix;
  }

  var badge = document.getElementById("open-badge");
  var badgeText = document.getElementById("open-text");
  if (badge && badgeText && span) {
    if (isOpen) {
      badgeText.textContent = "Open now · scooping until " + fmt(span[1]);
    } else {
      badge.classList.add("is-closed");
      badgeText.textContent = minutes < span[0]
        ? "Opens today at " + fmt(span[0])
        : "Closed · back tomorrow at 1 PM";
    }
  }
  var visitNote = document.getElementById("visit-open-note");
  if (visitNote && span) {
    visitNote.textContent = isOpen
      ? "Open right now — come get a cone."
      : "Currently closed — see you at the window soon.";
  }

  /* ------------------------------------------- live flavor board */
  /* Every page load pulls the saved board from the backend. cache:
     "no-store" guarantees a reload always shows the latest save. */
  function renderBoard(board) {
    if (!board || !Array.isArray(board.categories)) return;
    var total = 0;

    board.categories.forEach(function (cat) {
      var panel = document.getElementById("panel-" + cat.id);
      if (!panel) return;
      var list = panel.querySelector(".flavors");
      if (!list) return;

      list.textContent = "";
      (cat.flavors || []).forEach(function (flavor) {
        if (!flavor || !flavor.name) return;
        total += 1;
        var li = document.createElement("li");
        li.style.setProperty("--dot", flavor.dot || "#F6BFCB");
        li.appendChild(document.createTextNode(flavor.name));
        if (flavor.small) {
          li.appendChild(document.createTextNode(" "));
          var small = document.createElement("small");
          small.textContent = "(" + flavor.small + ")";
          li.appendChild(small);
        }
        list.appendChild(li);
      });

      var note = panel.querySelector(".panel-note");
      if (note) {
        if (cat.note) {
          note.textContent = cat.note;
          note.hidden = false;
          // Keep the signature name highlighted like the original design.
          if (cat.note.indexOf("Stirling Storm") !== -1) {
            var parts = cat.note.split("Stirling Storm");
            note.textContent = "";
            note.appendChild(document.createTextNode(parts[0]));
            var strong = document.createElement("strong");
            strong.textContent = "Stirling Storm";
            note.appendChild(strong);
            note.appendChild(document.createTextNode(parts.slice(1).join("Stirling Storm")));
          }
        } else {
          note.hidden = true;
        }
      }

      var tab = document.getElementById("tab-" + cat.id);
      if (tab && cat.label) tab.textContent = cat.label;
    });

    var kicker = document.querySelector("#flavors .kicker");
    if (kicker && total > 0) kicker.textContent = total + " ways to say yes";
  }

  function loadBoard() {
    fetch(API + "/sf/flavors", { cache: "no-store" })
      .then(function (res) { return res.ok ? res.json() : null; })
      .then(function (board) { if (board) renderBoard(board); })
      .catch(function () { /* offline — the built-in board stays up */ });
  }

  loadBoard();

  // Refresh when the tab regains focus so an admin edit shows up without
  // even needing a manual reload.
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible") loadBoard();
  });
})();


/* =============================================================================
   ===== FILE: admin.html =====
   ============================================================================= */

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Flavor Board Admin — The Stirling Fountain</title>
  <meta name="robots" content="noindex, nofollow" />
  <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='11' r='8' fill='%23F6BFCB'/%3E%3Cpath d='M8 14 L16 30 L24 14 Z' fill='%23E8A33D'/%3E%3Ccircle cx='16' cy='6' r='2.4' fill='%23C62F3B'/%3E%3C/svg%3E" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,700;0,9..144,900&family=Karla:wght@400;600;700&family=Yellowtail&display=swap" rel="stylesheet" />
  <style>
    :root {
      --cream: #FFF7EA; --paper: #FDEFDC; --ink: #3A2419; --red: #C62F3B;
      --red-dark: #A32531; --gold: #E8A33D; --mint: #BFE3D4; --pink: #F6BFCB;
      --line: #EAD9BE; --green: #3E7C4F;
      --shadow: 0 10px 30px rgba(58,36,25,0.12);
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: "Karla", system-ui, sans-serif; background: var(--cream); color: var(--ink); line-height: 1.5; padding-bottom: 80px; }
    h1, h2, h3 { font-family: "Fraunces", Georgia, serif; font-weight: 900; }
    .script { font-family: "Yellowtail", cursive; font-weight: 400; }
    button { font-family: inherit; cursor: pointer; }
    input { font-family: inherit; }

    .topbar { position: sticky; top: 0; z-index: 30; background: var(--ink); color: var(--cream); padding: 12px 18px; display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .topbar-brand { display: flex; align-items: baseline; gap: 8px; }
    .topbar-brand .script { color: var(--pink); font-size: 20px; }
    .topbar-brand small { font-size: 11px; text-transform: uppercase; letter-spacing: 0.2em; color: rgba(255,247,234,0.55); }
    .topbar-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }

    .status { display: inline-flex; align-items: center; gap: 7px; font-weight: 700; font-size: 13px; padding: 6px 14px; border-radius: 999px; background: rgba(255,247,234,0.12); }
    .status .dot { width: 8px; height: 8px; border-radius: 50%; background: rgba(255,247,234,0.4); }
    .status.is-saving .dot { background: var(--gold); animation: blink 0.8s infinite; }
    .status.is-saved .dot { background: #7ee0a3; }
    .status.is-error { background: rgba(198,47,59,0.35); }
    .status.is-error .dot { background: #ff8b8b; }
    @keyframes blink { 50% { opacity: 0.3; } }

    .wrap { max-width: 880px; margin: 0 auto; padding: 28px 16px; }
    .intro { background: #fff; border: 2px solid var(--line); border-radius: 18px; padding: 18px 22px; margin-bottom: 22px; box-shadow: var(--shadow); }
    .intro h1 { font-size: 24px; margin-bottom: 6px; }
    .intro p { font-size: 14px; color: rgba(58,36,25,0.7); }
    .intro .live-note { margin-top: 8px; font-size: 13px; font-weight: 700; color: var(--green); }

    .cat { background: #fff; border: 2px solid var(--line); border-radius: 18px; margin-bottom: 20px; box-shadow: var(--shadow); overflow: hidden; }
    .cat-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 16px 20px; background: var(--paper); border-bottom: 2px solid var(--line); flex-wrap: wrap; }
    .cat-head h2 { font-size: 19px; }
    .cat-head .count { font-size: 12.5px; font-weight: 700; color: rgba(58,36,25,0.55); background: #fff; border: 1px solid var(--line); border-radius: 999px; padding: 3px 12px; }
    .cat-body { padding: 14px 16px 18px; }

    .field-row { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 14px; }
    .field { flex: 1 1 220px; }
    .field label { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.14em; color: rgba(58,36,25,0.55); margin-bottom: 4px; }
    .field input { width: 100%; padding: 9px 12px; border: 2px solid var(--line); border-radius: 10px; font-size: 14px; background: var(--cream); }
    .field input:focus { outline: none; border-color: var(--gold); }

    .flavor-row { display: flex; align-items: center; gap: 8px; padding: 7px 0; border-bottom: 1px dashed var(--line); }
    .flavor-row:last-of-type { border-bottom: none; }
    .flavor-row input[type="color"] { width: 34px; height: 34px; border: 2px solid var(--line); border-radius: 50%; padding: 2px; background: #fff; cursor: pointer; flex-shrink: 0; }
    .flavor-row .f-name { flex: 2 1 160px; padding: 8px 12px; border: 2px solid transparent; border-radius: 10px; font-size: 15px; font-weight: 600; background: var(--cream); }
    .flavor-row .f-small { flex: 1 1 90px; padding: 8px 10px; border: 2px solid transparent; border-radius: 10px; font-size: 12.5px; background: var(--cream); color: rgba(58,36,25,0.7); }
    .flavor-row input:focus { outline: none; border-color: var(--gold); }
    .icon-btn { width: 32px; height: 32px; border-radius: 8px; border: 1.5px solid var(--line); background: #fff; font-size: 14px; line-height: 1; color: var(--ink); flex-shrink: 0; transition: all 0.15s ease; }
    .icon-btn:hover { border-color: var(--ink); transform: translateY(-1px); }
    .icon-btn.del:hover { background: var(--red); border-color: var(--red); color: #fff; }

    .add-btn { margin-top: 12px; width: 100%; padding: 11px; border: 2px dashed var(--line); border-radius: 12px; background: transparent; font-weight: 700; font-size: 14px; color: rgba(58,36,25,0.65); transition: all 0.15s ease; }
    .add-btn:hover { border-color: var(--red); color: var(--red); background: rgba(198,47,59,0.04); }

    .btn { display: inline-flex; align-items: center; gap: 7px; padding: 9px 18px; border-radius: 999px; border: 2px solid transparent; font-weight: 700; font-size: 13.5px; text-decoration: none; transition: transform 0.15s ease; }
    .btn:hover { transform: translateY(-1px); }
    .btn-solid { background: var(--red); color: #fff; }
    .btn-ghost { background: transparent; border-color: rgba(255,247,234,0.35); color: var(--cream); }
    .btn-ghost:hover { border-color: var(--cream); }
    .btn-danger-ghost { background: transparent; border-color: var(--line); color: rgba(58,36,25,0.6); font-size: 12.5px; padding: 7px 14px; }
    .btn-danger-ghost:hover { border-color: var(--red); color: var(--red); }

    .footer-tools { display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; margin-top: 6px; }
    .updated { font-size: 12.5px; color: rgba(58,36,25,0.55); }

    /* login gate */
    .gate { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .gate-card { background: #fff; border: 2px solid var(--line); border-radius: 22px; padding: 38px 34px; max-width: 400px; width: 100%; text-align: center; box-shadow: var(--shadow); }
    .gate-card .cone { width: 56px; margin: 0 auto 14px; }
    .gate-card h1 { font-size: 24px; margin-bottom: 4px; }
    .gate-card .script { color: var(--red); font-size: 22px; display: block; margin-bottom: 18px; }
    .gate-card input { width: 100%; padding: 12px 14px; border: 2px solid var(--line); border-radius: 12px; font-size: 15px; margin-bottom: 12px; background: var(--cream); }
    .gate-card input:focus { outline: none; border-color: var(--gold); }
    .gate-card .btn { width: 100%; justify-content: center; padding: 12px; font-size: 15px; }
    .gate-error { color: var(--red); font-weight: 700; font-size: 13.5px; margin-top: 10px; min-height: 20px; }

    .hidden { display: none !important; }
  </style>
</head>
<body>

  <!-- ============================================== login gate -->
  <div class="gate" id="gate">
    <div class="gate-card">
      <svg class="cone" viewBox="0 0 32 32" aria-hidden="true">
        <circle cx="16" cy="11" r="8" fill="#F6BFCB"/>
        <circle cx="10.5" cy="12.5" r="5.5" fill="#BFE3D4"/>
        <circle cx="21.5" cy="12.5" r="5.5" fill="#F6EBD8"/>
        <path d="M8.5 16 L16 30.5 L23.5 16 Z" fill="#E8A33D"/>
        <circle cx="16" cy="6.4" r="2.4" fill="#C62F3B"/>
      </svg>
      <h1>Flavor Board Admin</h1>
      <span class="script">The Stirling Fountain</span>
      <form id="gate-form">
        <input type="password" id="gate-pass" placeholder="Admin password" autocomplete="current-password" required />
        <button type="submit" class="btn btn-solid">Unlock the board</button>
      </form>
      <p class="gate-error" id="gate-error"></p>
    </div>
  </div>

  <!-- ============================================== editor -->
  <div id="app" class="hidden">
    <div class="topbar">
      <div class="topbar-brand">
        <span class="script">Stirling Fountain</span>
        <small>Flavor Board Admin</small>
      </div>
      <div class="topbar-actions">
        <span class="status" id="status"><span class="dot"></span><span id="status-text">Loading…</span></span>
        <a class="btn btn-ghost" href="./" target="_blank" rel="noopener">View live site ↗</a>
        <button class="btn btn-ghost" id="logout-btn" type="button">Lock</button>
      </div>
    </div>

    <div class="wrap">
      <div class="intro">
        <h1>Edit the Flavor Board</h1>
        <p>Every change saves automatically and goes live on the website immediately — visitors see the updated board the moment they open or reload the page.</p>
        <p class="live-note" id="live-note"></p>
      </div>

      <div id="categories"></div>

      <div class="footer-tools">
        <span class="updated" id="updated-label"></span>
        <button class="btn btn-danger-ghost" id="reset-btn" type="button">Restore original board</button>
      </div>
    </div>
  </div>

  <script>
    (function () {
      "use strict";

      var API = "https://tbstudios-backend.rork.app";
      var PASS_KEY = "sf_admin_pw";

      var board = null;
      var saveTimer = null;
      var saveSeq = 0;

      var gate = document.getElementById("gate");
      var app = document.getElementById("app");
      var statusEl = document.getElementById("status");
      var statusText = document.getElementById("status-text");
      var updatedLabel = document.getElementById("updated-label");
      var liveNote = document.getElementById("live-note");
      var categoriesEl = document.getElementById("categories");

      function pass() { return sessionStorage.getItem(PASS_KEY) || ""; }

      function setStatus(mode, text) {
        statusEl.className = "status" + (mode ? " is-" + mode : "");
        statusText.textContent = text;
      }

      function fmtTime(ts) {
        if (!ts) return "";
        var d = new Date(ts);
        return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
      }

      /* -------------------------------------------------- login */
      document.getElementById("gate-form").addEventListener("submit", function (e) {
        e.preventDefault();
        var pw = document.getElementById("gate-pass").value;
        var errEl = document.getElementById("gate-error");
        errEl.textContent = "";
        fetch(API + "/admin/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password: pw })
        }).then(function (res) {
          if (res.ok) {
            sessionStorage.setItem(PASS_KEY, pw);
            enter();
          } else if (res.status === 429) {
            errEl.textContent = "Too many attempts — try again in a few minutes.";
          } else {
            errEl.textContent = "Wrong password.";
          }
        }).catch(function () {
          errEl.textContent = "Can't reach the server — check your connection.";
        });
      });

      document.getElementById("logout-btn").addEventListener("click", function () {
        sessionStorage.removeItem(PASS_KEY);
        location.reload();
      });

      function enter() {
        gate.classList.add("hidden");
        app.classList.remove("hidden");
        load();
      }

      /* --------------------------------------------------- load */
      function load() {
        setStatus("saving", "Loading…");
        fetch(API + "/sf/flavors", { cache: "no-store" })
          .then(function (res) { return res.json(); })
          .then(function (data) {
            board = { categories: data.categories || [] };
            render();
            setStatus("saved", data.source === "saved" ? "Loaded saved board" : "Loaded original board");
            updatedLabel.textContent = data.updatedTs ? "Last published: " + fmtTime(data.updatedTs) : "Not customized yet — showing the original board.";
          })
          .catch(function () {
            setStatus("error", "Couldn't load — refresh to retry");
          });
      }

      /* -------------------------------------------------- render */
      function render() {
        categoriesEl.textContent = "";
        board.categories.forEach(function (cat, ci) {
          var box = document.createElement("div");
          box.className = "cat";

          var head = document.createElement("div");
          head.className = "cat-head";
          var h2 = document.createElement("h2");
          h2.textContent = cat.label || cat.id;
          var count = document.createElement("span");
          count.className = "count";
          count.textContent = cat.flavors.length + " flavor" + (cat.flavors.length === 1 ? "" : "s");
          head.appendChild(h2);
          head.appendChild(count);
          box.appendChild(head);

          var body = document.createElement("div");
          body.className = "cat-body";

          // label + note fields
          var fieldRow = document.createElement("div");
          fieldRow.className = "field-row";
          fieldRow.appendChild(makeField("Tab name", cat.label, function (v) { cat.label = v; h2.textContent = v || cat.id; queueSave(); }));
          fieldRow.appendChild(makeField("Note under the list (optional)", cat.note, function (v) { cat.note = v; queueSave(); }));
          body.appendChild(fieldRow);

          // flavor rows
          cat.flavors.forEach(function (flavor, fi) {
            body.appendChild(makeFlavorRow(cat, flavor, fi, count));
          });

          // add button
          var add = document.createElement("button");
          add.type = "button";
          add.className = "add-btn";
          add.textContent = "+ Add a flavor to " + (cat.label || cat.id);
          add.addEventListener("click", function () {
            cat.flavors.push({ name: "", dot: "#F6BFCB", small: "" });
            render();
            queueSave();
            // focus the new name input
            var rows = categoriesEl.querySelectorAll(".cat")[ci].querySelectorAll(".f-name");
            if (rows.length) rows[rows.length - 1].focus();
          });
          body.appendChild(add);

          box.appendChild(body);
          categoriesEl.appendChild(box);
        });
      }

      function makeField(labelText, value, onInput) {
        var wrap = document.createElement("div");
        wrap.className = "field";
        var label = document.createElement("label");
        label.textContent = labelText;
        var input = document.createElement("input");
        input.type = "text";
        input.value = value || "";
        input.addEventListener("input", function () { onInput(input.value); });
        wrap.appendChild(label);
        wrap.appendChild(input);
        return wrap;
      }

      function makeFlavorRow(cat, flavor, fi, countEl) {
        var row = document.createElement("div");
        row.className = "flavor-row";

        var color = document.createElement("input");
        color.type = "color";
        color.value = /^#[0-9a-fA-F]{6}$/.test(flavor.dot) ? flavor.dot : "#F6BFCB";
        color.title = "Dot color";
        color.addEventListener("input", function () { flavor.dot = color.value; queueSave(); });

        var name = document.createElement("input");
        name.type = "text";
        name.className = "f-name";
        name.placeholder = "Flavor name";
        name.value = flavor.name || "";
        name.addEventListener("input", function () { flavor.name = name.value; queueSave(); });

        var small = document.createElement("input");
        small.type = "text";
        small.className = "f-small";
        small.placeholder = "Tag (e.g. No Sugar Added)";
        small.value = flavor.small || "";
        small.addEventListener("input", function () { flavor.small = small.value; queueSave(); });

        var up = iconBtn("↑", "Move up", function () {
          if (fi === 0) return;
          var tmp = cat.flavors[fi - 1];
          cat.flavors[fi - 1] = cat.flavors[fi];
          cat.flavors[fi] = tmp;
          render();
          queueSave();
        });
        var down = iconBtn("↓", "Move down", function () {
          if (fi >= cat.flavors.length - 1) return;
          var tmp = cat.flavors[fi + 1];
          cat.flavors[fi + 1] = cat.flavors[fi];
          cat.flavors[fi] = tmp;
          render();
          queueSave();
        });
        var del = iconBtn("✕", "Remove", function () {
          cat.flavors.splice(fi, 1);
          render();
          queueSave();
        });
        del.classList.add("del");

        row.appendChild(color);
        row.appendChild(name);
        row.appendChild(small);
        row.appendChild(up);
        row.appendChild(down);
        row.appendChild(del);
        return row;
      }

      function iconBtn(glyph, title, onClick) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "icon-btn";
        b.textContent = glyph;
        b.title = title;
        b.addEventListener("click", onClick);
        return b;
      }

      /* ------------------------------------------------ autosave */
      function queueSave() {
        setStatus("saving", "Saving…");
        if (saveTimer) clearTimeout(saveTimer);
        saveTimer = setTimeout(save, 600);
      }

      function save() {
        var seq = ++saveSeq;
        fetch(API + "/sf/flavors", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Admin-Password": pass()
          },
          body: JSON.stringify({ categories: board.categories })
        }).then(function (res) {
          if (seq !== saveSeq) return; // a newer save is in flight
          if (res.ok) {
            return res.json().then(function (data) {
              setStatus("saved", "Saved — live on the site");
              updatedLabel.textContent = "Last published: " + fmtTime(data.updatedTs);
              liveNote.textContent = "✓ Published. Anyone opening or reloading the site now sees this board.";
            });
          }
          if (res.status === 401) {
            setStatus("error", "Session expired — reload and log in again");
          } else {
            setStatus("error", "Save failed — edit anything to retry");
          }
        }).catch(function () {
          if (seq !== saveSeq) return;
          setStatus("error", "Offline — edit anything to retry");
        });
      }

      /* ------------------------------------------------ reset */
      document.getElementById("reset-btn").addEventListener("click", function () {
        if (!confirm("Restore the original flavor board? Your custom changes will be removed.")) return;
        setStatus("saving", "Restoring…");
        fetch(API + "/sf/flavors/reset", {
          method: "POST",
          headers: { "X-Admin-Password": pass() }
        }).then(function (res) {
          if (!res.ok) throw new Error("reset failed");
          return res.json();
        }).then(function (data) {
          board = { categories: data.categories || [] };
          render();
          setStatus("saved", "Original board restored");
          updatedLabel.textContent = "Showing the original board.";
          liveNote.textContent = "✓ The site is back to the original flavor board.";
        }).catch(function () {
          setStatus("error", "Restore failed — try again");
        });
      });

      /* ------------------------------------------------ boot */
      if (pass()) {
        // Re-verify the stored password quietly; enter on success.
        fetch(API + "/admin/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ password: pass() })
        }).then(function (res) {
          if (res.ok) enter();
          else sessionStorage.removeItem(PASS_KEY);
        }).catch(function () { /* stay on gate */ });
      }
    })();
  </script>
</body>
</html>

